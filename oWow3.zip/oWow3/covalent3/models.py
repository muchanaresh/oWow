# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models

# Create your models here
class rommates(models.Model):
    firstname=models.CharField(max_length=100)
    lastname=models.CharField(max_length=100)
    age=models.IntegerField()
    job=models.CharField(max_length=100)
    designation=models.CharField(max_length=100)
    current_city=models.CharField(max_length=100)
    home_city=models.CharField(max_length=100)


       # def __str__(self):
           # return self.firstname

